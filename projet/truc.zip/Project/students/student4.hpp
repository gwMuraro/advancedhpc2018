#pragma once

#include "ppm.hpp"

float student4(const PPMBitmap& in, PPMBitmap& out, const int threshold);