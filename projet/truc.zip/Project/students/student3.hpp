#pragma once

#include "ppm.hpp"

float student3(const PPMBitmap& in, PPMBitmap& out, const int threshold);