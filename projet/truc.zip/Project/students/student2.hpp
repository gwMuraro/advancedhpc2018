#pragma once

#include "ppm.hpp"

float student2(const PPMBitmap& in, PPMBitmap& out, const int size);

// You may export your own class or functions to communicate data between the exercises ...